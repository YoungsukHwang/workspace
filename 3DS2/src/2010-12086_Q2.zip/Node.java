public class Node { //Node for question 2
	int data;
	Node left;
	Node right;

	public Node(int i) {
		// TODO Auto-generated constructor stub
		data = i;
	}

}
